//
//  ViewController.m
//  alertview
//
//  Created by Ashish on 07/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)btnActionLogin:(id)sender {
    if ([_txtemail.text isEqualToString:@""]) {
        [self Alert:@"Sign IN" alongWithMsg:@"Please enter email"];
        
       
    }else if ([_txtPassword.text isEqualToString:@""]){
        [self Alert:@"Sign IN" alongWithMsg:@"Please enter password"];
       
    }else if (_txtPassword.text.length <5){
       [self Alert:@"Sign IN" alongWithMsg:@"Password should be greater than four characters."];
       
        
    }else{
        [self Alert:@"Sign IN" alongWithMsg:@"Validation Done"];
    }
}

-(void)Alert:(NSString *)title alongWithMsg:(NSString *)msg{
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:msg preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"ok" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    
    
    [controller addAction:action];
    
    [self presentViewController:controller animated:YES completion:nil];
}
@end
