//
//  ViewController.h
//  alertview
//
//  Created by Ashish on 07/02/17.
//  Copyright © 2017 Ashish. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *email;
@property (weak, nonatomic) IBOutlet UILabel *passcode;
@property (weak, nonatomic) IBOutlet UITextField *txtemail;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;

- (IBAction)btnActionLogin:(id)sender;

@end

